f2 <-
function(x, y) x * y
